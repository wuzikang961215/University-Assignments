                        //
                        //
        tk_bool,        // 'bool'
        tk_case,        // 'case'
        tk_default,     // 'default'
        tk_do,          // 'do'
        tk_else,        // 'else'
        tk_if,          // 'if'
        tk_int,         // 'int'
        tk_let,         // 'let'
        tk_proc,        // 'proc'
        tk_return,      // 'return'
        tk_switch,      // 'switch'
        tk_while,       // 'while'

                         // The following tokens are not produced by the tokeniser
                         // These are provided to describe groups of tokens
        tg_statement,    // any token that can start the statement rule
        tg_labelled,     // any token that can start the labelled rule
        tg_label,        // any token that can start the label rule
        tg_operator,     // any token that can be used as an operator in the expression rule
        tg_type,         // any token that can start a term
        tg_term,         // any token that can start a type

        tk_last          // the last token value

