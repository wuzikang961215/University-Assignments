#ifndef PX1_TOKENISER_EXTRAS_H
#define PX1_TOKENISER_EXTRAS_H

#include "tokeniser.h"

// Interface for the workshop tokeniser
namespace Exam_Tokeniser
{
    // character groupings to make parsing code simpler
    // there is a character groupfor each grammar rule that start with more than one character
    // for use with next_char_isa(), next_char_mustbe() and did_not_find_char()
    enum Char:int
    {
        cg_min = 0x70000000,    // make all character groups start outside uni-code range

                                // each cg_* includes all characters that can start the matching rule
                                // *** if a rule can only start with a single character - there is no character group
        cg_wspace,              // characters that start rule wspace
        cg_isolated,
        cg_mixed,
        cg_note,
        cg_hex,
        cg_eol_char,
        cg_adhoc_char,
        cg_integer,
        cg_digit,
        cg_letter,
        cg_alnum,


        cg_oops,                //
        cg_eoi = EOF            // single character EOF
    } ;

    // ***** the following are implemented in the pre-compiled lib/libcs_w05.a object file *****

    // ***** Input functions *****
 
    // read the next character if not at the end of input
    // all input must be read using this function
    // the first call initialises the tokeniser
    extern void read_next_char() ;

    // ***** Error functions *****


    // ***** Parsing functions *****

    // report a fatal error and terminate the program
    // the error message will display the current position in the input
    extern void fatal_error_context(string error_message) ;

    // return true if ch == cg or ch is a member of character group cg
    extern bool char_isa(int ch,int cg) ;

    // return true if the next character is expected, otherwise false
    // this is implemented by calling char_isa()
    extern bool next_char_isa(int expected) ;

    // report an error and exit because the next character in the input is not expected?
    // this calls next_char_isa(expected) to differentiate between syntax and logic errors
    extern void did_not_find_char(int expected) ;

    // if next_char_isa(expected) returns true then call read_next_char(),
    // otherwise call did_not_find_char()
    extern void next_char_mustbe(int expected) ;

    // ***** Token functions *****
 
    // if s is a keyword this returns the token kind for keyword s otherwise this returns tk_identifier
    extern TokenKind keyword_or_identifier(string s) ;

    // create a new Token object of the given kind using all characters parsed since the last call
    // it calls classify_spelling() to work out the kind of token that was parsed
    // it calls correct_spelling() to work out the spelling of the token
    extern Token new_token() ;

    // ***** the following are implemented in the tokeniser-extras.cpp file *****

    // work out the kind of a parsed token
    // this calls keyword_or_identifier(spelling) to check if an identifier is really a keyword
    // the spelling is a valid token
    // this is called by new_token()
    extern TokenKind classify_spelling(string spelling) ;

    // work out the correct spelling to use in the Token object being created by new_token()
    // the spelling is a valid token and kind is the token's kind
    // this is called by new_token()
    extern string correct_spelling(TokenKind kind,string spelling) ;

}

#endif //PX1_TOKENISER_EXTRAS_H
