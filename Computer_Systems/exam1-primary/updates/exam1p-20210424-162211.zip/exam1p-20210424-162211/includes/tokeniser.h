#ifndef PX1_TOKENISER_H
#define PX1_TOKENISER_H

#include <string>

// Interface for the workshop tokeniser
namespace Exam_Tokeniser
{
    // shorthand name for the string type
    typedef std::string string ;

    // the ID used to reference a Token - the implementation is hidden
    class _Token ;
    typedef _Token *Token ;

    // The kinds of token that are recognised?
    enum TokenKind : unsigned int
    {
        // Exam Language Tokeniser Tokens
        // Grammar rule:        Definition
        // input ::=            token* eoi
        // ... see web submission test script for remainder of the grammar rules
        //
        // * only the following token kinds can be returned by your tokeniser
        //
        tk_tab,
        tk_newline,
        tk_carriage_return,
        tk_space,
        tk_at,
        tk_rsb,
        tk_lrb,
        tk_semi,
        tk_add,
        tk_ne,
        tk_dec,
        tk_lt,
        tk_spaceship,
        tk_divide,
        tk_identifier,
        tk_number,
        tk_cpp,
        tk_javadoc,

        tk_eoi,             // end of input reached
        tk_oops             // just in case
    } ;

    // ***** the following are implemented in the pre-compiled library files *****

    // return a string representation of the given token kind or ""
    extern string to_string(TokenKind kind) ;

    // return the TokenKind for the given token
    extern TokenKind token_kind(Token token) ;

    // return the spelling for the given token
    extern string token_spelling(Token token) ;

    // return a string representation of the given token
    extern string to_string(Token token) ;

    // ***** the following function is implemented by completing tokeniser.cpp and tokeniser-extras.cpp *****

    // read the next token from standard input - the first call initialises the tokeniser
    extern Token read_next_token() ;
}

#endif //PX1_TOKENISER_H
