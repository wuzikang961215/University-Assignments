// tokeniser implementation for the workshop example language

#include "tokeniser-extras.h"

// to shorten the code
using namespace std ;

// we are extending the Exam_Tokeniser namespace

namespace Exam_Tokeniser
{
    // Add additonal parsing functions here ...





    // token ::= ...
    static void parse_token()
    {
        // Add your code here ...

        // ....

        // catch all error if next character cannot start a token
        fatal_error_context("parse_token() did not find a character that can start a token") ;
    }

    // if not at the end of input, parse the next token in the input and return a new
    // Token object that describes its kind and spelling
    // Note: you must not call new_token() anywhere else in your program
    //
    Token read_next_token()
    {
        if ( !next_char_isa(EOF) ) parse_token() ;

        return new_token() ;
    }
}

