// convert Text into Tokens wrapped up in XML
#include "iobuffer.h"
#include "tokeniser-extras.h"
#include <unordered_map>
#include <iostream>
#include <vector>

// to shorten the code
using namespace std ;
using namespace CS_IO_Buffers ;

namespace Exam_Tokeniser
{

    // check if a char matches another char or is a member of a character group
    // eg token_is(tk_colon,tk_colon) returns true
    // eg token_is(tk_sub,tg_op) returns true
    bool char_isa(int ch,int cg)
    {
        if ( ch == cg ) return true ;

        switch(cg)
        {
        case cg_wspace:         // could ch start grammar rule wspace?
            switch(ch)
            {
            case '\t':
            case '\n':
            case '\r':
            case ' ':
                return true ;
            default:
                return false ;
            }

        case cg_isolated:       // could ch start grammar rule isolated?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_mixed:          // could ch start grammar rule mixed?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_note:           // could ch start grammar rule note?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_hex:            // could ch start grammar rule hex?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_eol_char:       // could ch start grammar rule eol_char?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_adhoc_char:     // could ch start grammar rule adhoc_char?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_digit:          // could ch start grammar rule digit?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_letter:         // could ch start grammar rule letter?
            switch(ch)
            {
            default:
                return false ;
            }

        case cg_alnum:          // could ch start grammar rule alnum?
            switch(ch)
            {
            default:
                return false ;
            }

        default:
            return false ;
        }
    }

    // work out the kind of a parsed token
    // the spelling is a valid token
    // this is called by new_token()
    TokenKind classify_spelling(string spelling)
    {
        if ( spelling == "" ) return tk_eoi ;

        return tk_oops ;
    }

    // work out the correct spelling to use in the Token object being created by new_token()
    // the spelling is a valid token and kind is the token's kind
    // this is called by new_token()
    string correct_spelling(TokenKind kind,string spelling)
    {
        return spelling ;
    }

}
